package ai.mrmwsk.ai

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private data class ChatLine(val text: String, val user: Boolean)
class MainActivity : ComponentActivity() {
    private var modelPath by mutableStateOf("")
    private var modelName by mutableStateOf("No local model selected")
    private var status by mutableStateOf("Offline AI ready — import a GGUF model to begin")
    private var busy by mutableStateOf(false)
    private val lines = mutableStateListOf<ChatLine>()
    private val chooseModel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importModel(uri)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MrMWSKApp(
            modelName = modelName, status = status, busy = busy, lines = lines,
            onChoose = { chooseModel.launch(arrayOf("application/octet-stream", "*/*")) },
            onSend = { send(it) }
        ) }
    }
    private fun importModel(uri: Uri) {
        lifecycleScope.launch {
            busy = true; status = "Copying model into private app storage…"
            try {
                val file = withContext(Dispatchers.IO) {
                    val name = "selected-model.gguf"
                    val dest = File(filesDir, "models").apply { mkdirs() }.resolve(name)
                    contentResolver.openInputStream(uri)!!.use { input ->
                        dest.outputStream().use { output -> input.copyTo(output) }
                    }
                    dest
                }
                status = "Loading model — first load may take a while"
                val ok = withContext(Dispatchers.IO) {
                    LlamaBridge.nativeLoad(file.absolutePath, 4, 2048)
                }
                if (ok) {
                    modelPath = file.absolutePath
                    modelName = file.name
                    status = "Model loaded locally. Prompts stay on this device."
                } else status = "Model load failed. Check GGUF compatibility and free memory."
            } catch (e: Exception) { status = "Import failed: ${e.message ?: "unknown error"}" }
            busy = false
        }
    }
    private fun send(message: String) {
        if (message.isBlank() || busy) return
        if (modelPath.isBlank()) { status = "Import a GGUF model first."; return }
        lines.add(ChatLine(message, true))
        busy = true; status = "Generating locally…"
        lifecycleScope.launch {
            val prompt = lines.takeLast(12).joinToString("\n\n") {
                if (it.user) "User: ${it.text}" else "Assistant: ${it.text}"
            }
            val answer = withContext(Dispatchers.Default) { LlamaBridge.nativeGenerate(prompt, 256) }
            lines.add(ChatLine(answer.ifBlank { "The model returned an empty response." }, false))
            status = "Local generation complete"
            busy = false
        }
    }
    override fun onDestroy() {
        if (isFinishing) runCatching { LlamaBridge.nativeUnload() }
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MrMWSKApp(
    modelName: String, status: String, busy: Boolean, lines: List<ChatLine>,
    onChoose: () -> Unit, onSend: (String) -> Unit
) {
    var input by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(0) }
    val bg = Color(0xFF0A100F)
    val panel = Color(0xFF151F1C)
    val accent = Color(0xFFB7E4C7)
    MaterialTheme(colorScheme = darkColorScheme(
        primary = accent, background = bg, surface = panel,
        onBackground = Color(0xFFEAF2ED), onSurface = Color(0xFFEAF2ED)
    )) {
        Scaffold(containerColor = bg, topBar = {
            TopAppBar(title = {
                Column {
                    Text("MrMWSK's AI", fontWeight = FontWeight.Bold)
                    Text("PRIVATE • OFFLINE FIRST", style = MaterialTheme.typography.labelSmall,
                        color = accent)
                }
            }, colors = TopAppBarDefaults.topAppBarColors(containerColor = bg))
        }, bottomBar = {
            NavigationBar(containerColor = panel) {
                listOf("Chat", "Models", "Settings", "About").forEachIndexed { i, label ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Icon(if (i == 0) Icons.Default.Chat else if (i == 1) Icons.Default.Memory else if (i == 2) Icons.Default.Settings else Icons.Default.Person, null) },
                        label = { Text(label) })
                }
            }
        }) { padding ->
            when (tab) {
                0 -> Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                    Card(colors = CardDefaults.cardColors(containerColor = panel)) {
                        Column(Modifier.padding(14.dp)) {
                            Text(if (modelName == "No local model selected") "Welcome back" else "Local model active",
                                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(status, style = MaterialTheme.typography.bodySmall, color = accent)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    if (lines.isEmpty()) {
                        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.AutoAwesome, null, tint = accent, modifier = Modifier.size(42.dp))
                                Spacer(Modifier.height(10.dp))
                                Text("What would you like to explore?")
                                Text("Your prompts remain on this device.", color = Color.LightGray,
                                    style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    } else {
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(lines) { line ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement =
                                    if (line.user) Arrangement.End else Arrangement.Start) {
                                    Surface(color = if (line.user) Color(0xFF254A3A) else panel,
                                        shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 320.dp)) {
                                        Text(line.text, Modifier.padding(12.dp))
                                    }
                                }
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = input, onValueChange = { input = it },
                            modifier = Modifier.weight(1f), placeholder = { Text("Message MrMWSK's AI…") },
                            enabled = !busy, maxLines = 4)
                        IconButton(enabled = !busy && input.isNotBlank(), onClick = {
                            onSend(input.trim()); input = ""
                        }) { Icon(Icons.Default.Send, "Send", tint = accent) }
                    }
                }
                1 -> Column(Modifier.fillMaxSize().padding(padding).padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Model manager", style = MaterialTheme.typography.headlineSmall)
                    Text("Import a compatible GGUF model stored on your phone. Large files need sufficient free storage.")
                    Card(colors = CardDefaults.cardColors(containerColor = panel)) {
                        Column(Modifier.padding(16.dp)) {
                            Text(modelName, fontWeight = FontWeight.Bold)
                            Text(status, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Button(onClick = onChoose, enabled = !busy) {
                        Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("Import GGUF model")
                    }
                    Text("A small 1B–3B instruct model in a 4-bit GGUF quantization is a sensible first experiment. Actual speed and memory use must be tested on this phone.")
                }
                2 -> Column(Modifier.fillMaxSize().padding(padding).padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Performance & privacy", style = MaterialTheme.typography.headlineSmall)
                    Text("Profile: Balanced (initial)")
                    Text("Runtime: llama.cpp • CPU backend first")
                    Text("Context: 2,048 tokens (conservative starter)")
                    Text("Threads: 4 (starter setting)")
                    Text("Network: Offline-only in this first build")
                    Text("Device: Samsung Galaxy A54 5G target")
                    Text("No chat or document upload is implemented in this starter.")
                }
                else -> Column(Modifier.fillMaxSize().padding(padding).padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("About MrMWSK's AI", style = MaterialTheme.typography.headlineSmall)
                    Text("Created under the MrMWSK brand. The founder portraits are optional identity artwork.")
                    androidx.compose.foundation.Image(
                        painter = androidx.compose.ui.res.painterResource(R.drawable.founder_photo),
                        contentDescription = "Founder portrait",
                        modifier = Modifier.fillMaxWidth().height(190.dp)
                    )
                    androidx.compose.foundation.Image(
                        painter = androidx.compose.ui.res.painterResource(R.drawable.founder_artistic_portrait),
                        contentDescription = "Artistic founder portrait",
                        modifier = Modifier.fillMaxWidth().height(190.dp)
                    )
                    Text("PainKiller is a separate brand. Its logo is retained here as a reference, not used as the MrMWSK's AI app logo.")
                    androidx.compose.foundation.Image(
                        painter = androidx.compose.ui.res.painterResource(R.drawable.painkiller_brand_reference),
                        contentDescription = "PainKiller brand reference logo",
                        modifier = Modifier.fillMaxWidth().height(160.dp)
                    )
                }
            }
        }
    }
}
