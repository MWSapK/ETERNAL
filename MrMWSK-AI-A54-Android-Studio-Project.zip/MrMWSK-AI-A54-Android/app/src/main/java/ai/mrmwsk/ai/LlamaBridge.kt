package ai.mrmwsk.ai

object LlamaBridge {
    init { System.loadLibrary("mrmwsk_llama") }
    external fun nativeLoad(path: String, threads: Int, context: Int): Boolean
    external fun nativeGenerate(prompt: String, maxTokens: Int): String
    external fun nativeUnload()
}
