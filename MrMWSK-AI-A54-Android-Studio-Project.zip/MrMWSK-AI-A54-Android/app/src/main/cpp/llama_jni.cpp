#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>
#include "llama.h"

static llama_model* g_model = nullptr;
static llama_context* g_ctx = nullptr;
static std::mutex g_mutex;

extern "C" JNIEXPORT jboolean JNICALL
Java_ai_mrmwsk_ai_LlamaBridge_nativeLoad(JNIEnv* env, jobject, jstring path, jint threads, jint context) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    const char* p = env->GetStringUTFChars(path, nullptr);
    llama_backend_init();
    auto mp = llama_model_default_params();
    g_model = llama_model_load_from_file(p, mp);
    env->ReleaseStringUTFChars(path, p);
    if (!g_model) return JNI_FALSE;
    auto cp = llama_context_default_params();
    cp.n_ctx = (uint32_t)context;
    cp.n_threads = threads;
    cp.n_threads_batch = threads;
    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) { llama_model_free(g_model); g_model = nullptr; return JNI_FALSE; }
    return JNI_TRUE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_ai_mrmwsk_ai_LlamaBridge_nativeGenerate(JNIEnv* env, jobject, jstring prompt, jint maxTokens) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_model || !g_ctx) return env->NewStringUTF("No model is loaded. Select a GGUF model first.");
    const char* input = env->GetStringUTFChars(prompt, nullptr);
    std::string text(input);
    env->ReleaseStringUTFChars(prompt, input);

    // Use the GGUF model's own chat template when llama.cpp supports it.
    const char* chatTemplate = llama_model_chat_template(g_model, nullptr);
    if (chatTemplate != nullptr) {
        const llama_chat_message messages[] = {
            {"system", "You are MrMWSK's AI, a helpful, accurate assistant. Be clear and honest."},
            {"user", text.c_str()}
        };
        std::vector<char> formatted(std::max<size_t>(2048, text.size() * 2 + 1024));
        int formattedSize = llama_chat_apply_template(chatTemplate, messages, 2, true,
                                                       formatted.data(), (int)formatted.size());
        if (formattedSize > 0) {
            if ((size_t)formattedSize > formatted.size()) {
                formatted.resize((size_t)formattedSize + 1);
                formattedSize = llama_chat_apply_template(chatTemplate, messages, 2, true,
                                                           formatted.data(), (int)formatted.size());
            }
            if (formattedSize > 0) text.assign(formatted.data(), (size_t)formattedSize);
        }
    }

    const llama_vocab* vocab = llama_model_get_vocab(g_model);
    std::vector<llama_token> tokens(text.size() + 16);
    int n = llama_tokenize(vocab, text.c_str(), (int)text.size(), tokens.data(),
                           (int)tokens.size(), true, true);
    if (n < 0) { tokens.resize((size_t)(-n)); n = llama_tokenize(vocab, text.c_str(),
        (int)text.size(), tokens.data(), (int)tokens.size(), true, true); }
    if (n <= 0) return env->NewStringUTF("I couldn't tokenize that prompt.");
    tokens.resize((size_t)n);
    llama_memory_clear(llama_get_memory(g_ctx), true);
    llama_batch batch = llama_batch_get_one(tokens.data(), (int)tokens.size());
    if (llama_decode(g_ctx, batch) != 0) return env->NewStringUTF("Prompt processing failed.");
    auto* sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(sampler, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(sampler, llama_sampler_init_top_p(0.90f, 1));
    llama_sampler_chain_add(sampler, llama_sampler_init_temp(0.75f));
    llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    std::string output;
    std::vector<char> piece(8192);
    for (int i = 0; i < maxTokens; ++i) {
        llama_token tok = llama_sampler_sample(sampler, g_ctx, -1);
        if (llama_vocab_is_eog(vocab, tok)) break;
        int len = llama_token_to_piece(vocab, tok, piece.data(), (int)piece.size(), 0, true);
        if (len > 0) output.append(piece.data(), (size_t)len);
        llama_token next = tok;
        batch = llama_batch_get_one(&next, 1);
        if (llama_decode(g_ctx, batch) != 0) break;
    }
    llama_sampler_free(sampler);
    return env->NewStringUTF(output.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_ai_mrmwsk_ai_LlamaBridge_nativeUnload(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
}
