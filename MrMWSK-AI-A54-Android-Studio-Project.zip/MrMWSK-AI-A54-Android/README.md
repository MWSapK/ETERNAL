# MrMWSK's AI — Samsung Galaxy A54 5G Android project

This is the **native Android foundation** for MrMWSK's AI, separate from the existing web/PWA app. It targets `arm64-v8a`, uses Kotlin + Jetpack Compose, and fetches the upstream `ggml-org/llama.cpp` source at CMake configuration time to compile a local GGUF inference library.

## Open in Android Studio
1. Extract this ZIP.
2. In Android Studio choose **Open** and select this folder (`MrMWSK-AI-A54-Android`).
3. Install Android SDK Platform 36, Android NDK, and CMake 3.31.6 in SDK Manager.
4. Sync Gradle (Gradle 8.13 / JDK 17 or 21). The first native configuration needs internet to fetch llama.cpp.
5. Build and install the debug app on the Galaxy A54 5G.

## First run
1. In Models, import a compatible `.gguf` model from device storage.
2. Allow time and storage for the model to be copied into app-private storage.
3. Return to Chat and send a prompt. Once model and app are installed, inference is local; the app does not make AI network calls.

## A54 starting profile
- ARM64 only.
- Four inference threads as a conservative initial setting.
- 2,048-token context.
- CPU backend; no claim of GPU/NPU acceleration.
- Start with a small 1B–3B instruct model in a 4-bit quantization. Model choice, license, exact size and device memory should be checked before download.

**RAM note:** the user-reported 12 GB may include Samsung RAM Plus (storage-backed virtual memory). Android's available physical RAM and memory class are what matter for model sizing. Do not size models from the marketing/combined figure alone.

## Important status and limitations
This is an early engineering milestone, not a finished ChatGPT-equivalent app and not a Play Store release. It implements a native Compose chat shell, local GGUF import, a llama.cpp JNI inference path, and a basic local generation flow. It does not yet implement streaming tokens, robust chat-template selection for every model family, model catalog/download manager, Room history, RAG/document reading, voice, vision, cloud providers, or Play signing. The current JNI prompt wrapper is intentionally simple and should be upgraded to model-aware chat-template formatting before broad model compatibility is claimed.

The CMake project tracks upstream llama.cpp `master`; for reproducible production builds, pin a reviewed commit and test the exact Android NDK/CMake versions. Native compilation must be verified on an actual Android build host. This environment did not produce or test an APK.

## Branding assets\nThe About tab includes the supplied founder photograph, artistic portrait, and PainKiller logo as references. PainKiller is intentionally identified as a separate brand and is not used as the MrMWSK's AI app icon.\n\n## Upstream
- llama.cpp: https://github.com/ggml-org/llama.cpp
- Android build guidance: https://github.com/ggml-org/llama.cpp/blob/master/docs/android.md
- License: see upstream llama.cpp LICENSE and each selected model's own license.
